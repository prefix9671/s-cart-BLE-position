/** Automatically generated file. DO NOT MODIFY */
package com.example.n_mart;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}