# Smart-Cart

#### 비콘을 활용한 경로 탐색 스마트카트

#### Smartcart to navigate route using Beacon


컴퓨터공학전공
2014150009
김현욱

컴퓨터공학전공
2014154001
강준혁

컴퓨터공학전공
2015152053
조시우

컴퓨터공학전공
2016154048
염은경



## Documents

### Scenario

Mart Blueprint - https://drive.google.com/file/d/1Vyx84cEgMwQ5F3fMFKftvBWOSWkSUQtV/view?usp=sharing

Shopping Scenario - https://drive.google.com/file/d/1AC6yfMcURjZ_iLCAYCf--v9AuPsDMMej/view?usp=sharing
